/**
 * FILL IN YOUR HEADING INFORMATION :-) 
 * (See Syllabus for style but DO NOT copy from pdf document -> compile error)
 */
import java.util.*;

public class PostageCalc
{
    public static void main (String [ ] args)
    {
        System.out.println("Welcome to the Postage Calculator Program"); 
        System.out.println("This program will calculate postage "
                         + "for items up to 2 pounds.");
        System.out.println("------------------------------------"
                         + "-------------------------");
        System.out.println();
        
        // set up Scanner to get keyboard input
        Scanner keyboard = new Scanner (System.in);

        for (int i = 0; i < 5; i++) {            
            double cost = 0.0;  // holds cost of mailing

            System.out.println("You can choose postcard, letter, or parcel.");
            System.out.print ("Type the kind of item you wish to send: ");
            String item = keyboard.next();

            //***********//
            //*** PLACE YOUR CODE IN THIS SECTION OF THE PROGRAM. ***//
            //*** PLEASE DELETE THESE LINES WHEN FINISHED. ***//
            //***********//

            // You will need an if-statement to determine if you print this line
            System.out.printf("Cost of mailing "); // currently incomplete
        }
    }
}
